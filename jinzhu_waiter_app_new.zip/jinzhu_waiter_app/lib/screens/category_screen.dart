import 'package:flutter/material.dart';
import 'menu_screen.dart';

class CategoryScreen extends StatefulWidget {
  @override
  _CategoryScreenState createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  final List<String> categories = ["All", "Mains", "Drinks", "Desserts", "Sides"];
  String selected = "All";

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text("Categories"),
        actions: [
          IconButton(onPressed: (){
            Navigator.pushNamed(context, '/cart');
          }, icon: Icon(Icons.shopping_cart))
        ],
      ),
      body: Row(
        children: [
          Container(
            width: 160,
            color: Colors.grey[100],
            child: ListView(
              children: categories.map((c) => ListTile(
                title: Text(c),
                selected: c == selected,
                onTap: () => setState(()=> selected = c),
              )).toList(),
            ),
          ),
          Expanded(
            child: MenuScreen(category: selected),
          )
        ],
      ),
    );
  }
}
